___assertEqual(len(()), 0)
___assertEqual(len((0,)), 1)
___assertEqual(len((0, 1, 2)), 3)
