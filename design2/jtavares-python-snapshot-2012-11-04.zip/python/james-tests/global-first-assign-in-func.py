def foo():
    global x
    x = 3

foo()

print(x)
