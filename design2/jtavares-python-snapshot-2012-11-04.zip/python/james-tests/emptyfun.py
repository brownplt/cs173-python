def foo():
    pass

print("calling foo...");
foo()
print("done");
