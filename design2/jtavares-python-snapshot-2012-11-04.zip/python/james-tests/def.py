def noargs():
    print("noargs")

def onearg(x):
    print(x)

def twoargs(x,y):
    print(x)
    print(y)

noargs()
onearg("onearg")
twoargs("two", "args")
