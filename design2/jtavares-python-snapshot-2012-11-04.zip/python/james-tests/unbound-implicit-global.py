def foo():
    print(x)

foo()

