def noargs():
    print("noargs success!")

noargs()
noargs()

